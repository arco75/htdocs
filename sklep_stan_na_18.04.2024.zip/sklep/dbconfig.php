<?PHP
$server="localhost";
$user="operatorsklep";
$pass="123456";
$base="sklep";
?>